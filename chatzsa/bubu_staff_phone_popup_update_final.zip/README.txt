BUBU staff phone final alignment update

Fixes:
- All popups centered on phone
- Prevents pages/cards/forms from exceeding screen width
- Buttons grow to fit text
- Nested field groups align correctly
- Two-column phone layout where suitable
- One-column fallback only on extremely narrow phones
- No Python, model, migration, or database changes
